// document.addEventListener("DOMContentLoaded", 
//     function() {
//         alert("JavaScript is working on your Django website!");
//     });


// static/admin_chart.js

$(document).ready(function () {
    var ctx = document.getElementById('documentRequestsChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: documentRequestsChart.labels,
        datasets: [{
          label: 'Number of Document Requests',
          data: documentRequestsChart.data,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
        }]
      },
      options: documentRequestsChart.options
    });
  });
  